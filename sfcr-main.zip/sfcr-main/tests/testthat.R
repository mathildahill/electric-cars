library(testthat)
library(sfcr)

test_check("sfcr")
